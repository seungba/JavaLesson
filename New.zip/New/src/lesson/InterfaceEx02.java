package lesson;

public interface InterfaceEx02 {
	public void method01();
	 public void method02();

	public void method03();

	public void method04();
	
	abstract public void method05();
}
