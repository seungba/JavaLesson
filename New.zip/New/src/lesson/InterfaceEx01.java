package lesson;

public class InterfaceEx01 implements InterfaceEx02 {

	@Override
	public void method01() {
		System.out.println("aaaaaaaaaa");
	}

	@Override
	public void method02() {
	}

	@Override
	public void method03() {
	}

	@Override
	public void method04() {
	}

	@Override
	public void method05() {
	}

	public void diss() {
		
	}
}
