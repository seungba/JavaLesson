package lesson;

abstract public class AbstractEx1 {
	
	// �Ϲ�
	public void method7() {
		System.out.println("dsfsdfsfsdf");
	}
	
	// �Ϲ�
	public void method8 () {
		
	}
	
	// �߻�
	abstract public void method9();
	
}
