package lesson;

public class Sangsok2 {
	public String str2 = "str2";
	private int num2 = 2;
	
	public Sangsok2() {
		//System.out.println("Sangsok2 ������");
	}
	
	public String getStr2() {
		return str2;
	}
	public void setStr2(String str2) {
		this.str2 = str2;
	}
	public int getNum2() {
		return num2;
	}
	public void setNum2(int num2) {
		this.num2 = num2;
	}
	
	public void disp() {
		System.out.println("[Sangsok2] disp");
	}
	
}