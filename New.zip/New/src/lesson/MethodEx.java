package lesson;

public class MethodEx {
	
	public void method1() {
		
	}
	
	public void method1(String str) {
		
	}
	
	public void method1(int str) {
		
	}
	
	public void method1(int num, String str)  {
		
	}

	public void method1(String num, int str)  {
		
	}
	
	public static void main(String[] sdfhsdkdfklfds) {
		System.out.println("3"+1+1);	// 32
		System.out.println(3+1+"1");	// 41
		System.out.println(3+"1"+1);	// 311
		System.out.println(3+2*5);		// 310
	}
}