package lesson;

public class AbstractEx2 extends AbstractEx1{

	@Override
	public void method9() {
		
	}
}
