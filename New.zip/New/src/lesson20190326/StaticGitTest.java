package lesson20190326;

public class StaticGitTest {

}
