package lesson20190326;

public class StaticEx4 {
	public static void init4() {
		
		StaticEx01 a1 = new StaticEx01();
		a1.numDisp1();		// 0
		a1.numDisp1();		// 1
		a1.numDisp1();		// 2
		
//		StaticEx01.numDisp();		// 0
//		StaticEx01.numDisp();		// 0
//		StaticEx01.numDisp();		// 0	
	}
}
